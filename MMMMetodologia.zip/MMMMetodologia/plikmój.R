library(modelr)
library(kableExtra)
library(ggplot2)
library(ggthemes)
library(dplyr)
library(knitr)
library(nycflights13)
library(forcats)
library(tidyverse)

smallpox <- read.csv ("m23t1/globalSmallpoxCases.csv",
                      header = TRUE)

head(smallpox)

names(smallpox)[4] <- "cases"

names(smallpox)

smallpox <- smallpox [,-2]

names (smallpox)

mean (smallpox$cases)

median (smallpox$cases)

mean(smallpox$cases [smallpox$Year >= 1920 & smallpox$Year <= 1930])

median(smallpox$cases [smallpox$Year >=1920 & smallpox$Year <=1930])

mean(smallpox$cases [smallpox$Year >= 1930 & smallpox$Year <= 1950])

median(smallpox$cases [smallpox$Year >=1930 & smallpox$Year <=1950])

mean(smallpox$cases [smallpox$Year >= 1950 & smallpox$Year <= 1970])

median(smallpox$cases [smallpox$Year >=1950 & smallpox$Year <=1970])


ggplot(smallpox, aes(x = Year, y = cases))+
  stat_summary(fun=mean, colour="skyblue", geom="line", aes(group = 1))+
  theme_tufte()

ggplot(heights, aes(x= education, y = income))+
  geom_point(width = 0.5, alpha = 0.2)+
  stat_summary(fun=mean, colour="red", geom="line", aes(group = 1))+
  theme_tufte()

ggplot(heights, aes(x= education, y = income, aes,colour=sex))+
  geom_point()+
  stat_summary(fun=median, geom="line", size=2) +
  facet_wrap(~ marital, nrow = 2) + theme_tufte()

ggplot(heights,aes(x = education, y = income, aes,colour=sex)) +
  geom_smooth(size=0.2)+geom_point()+theme_tufte()

head(faithful)

ggplot(faithful, aes(x = waiting, y = eruptions)) + 
  geom_point()

